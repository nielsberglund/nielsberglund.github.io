﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KafkaSqlClrProducer;

namespace KafkaSqlConsole
{
    class Program
    {
        static string _libRdDirectory = "C:\\librdkafka2\\librdkafka.dll";
        static string _bootstrapServer = "localhost:9092";

        static async Task Main()
        {
            var offset = KafkaProducer.PostMessage(_bootstrapServer, "testTopic", _libRdDirectory, "1", "Hello World");
            Console.WriteLine($"delivered to offset: {offset}");

        }




        //static async Task Main(string[] args)
        //{
        //    var config = new ProducerConfig { BootstrapServers = _bootstrapServer };
        //    string topicName = "testTopic";
            
        //    if (!Library.IsLoaded)
        //    {
        //        Library.Load(_libRdDirectory);
        //    }
            
        //    using (var producer = new ProducerBuilder<string, string>(config).Build())
        //    {
        //        var deliveryReport = await producer.ProduceAsync(topicName, new Message<string, string> { Key = "1", Value = "Hello World" });
        //        Console.WriteLine($"delivered to: {deliveryReport.TopicPartitionOffset}");

        //    }

        //}
    }
}
