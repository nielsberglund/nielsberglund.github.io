﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Confluent.Kafka;

namespace KafkaSqlClrProducer
{
    public partial class KafkaProducer
    {
        public static int PostMessage(string bootStrapServers, string topic, string libRdPath, string partitionKey, string value)
        {
            var deliveryReport = SendMessage(bootStrapServers, topic, libRdPath, partitionKey, value);
            return (int)deliveryReport.Result;
        }

        public static async Task<long> SendMessage(string bootStrapServers, string topic, string libRdPath, string partitionKey, string value)
        {
            var config = new ProducerConfig { BootstrapServers = bootStrapServers };
            Library.Load(libRdPath);
            using (var producer = new ProducerBuilder<string, string>(config).Build())
            {
                var deliveryReport = await producer.ProduceAsync(topic, new Message<string, string> { Key = partitionKey, Value = value });
                return deliveryReport.Offset;
            }
        }
    }
}
