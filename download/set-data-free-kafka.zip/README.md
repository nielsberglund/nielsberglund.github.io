# Free Your SQL Server Data with the Use of Kafka

The included folders in this zip file contains the slide deck and code for the SQLBits presentation **Free Your SQL Server Data with the Use of Kafka**.

After extracting the content of the .zip, open the notebook `README-Intro.ipynb` in Azure Data Studio, That notebook contains the instructions of how to run the included code.